ChristianBox 4.0.0
==================

A free music maker built on BeepBox, with a Composer that writes music with you.

To start it, run ./christian-box in this folder. It opens as its own window in Chromium, Chrome, Edge or Brave if one is installed, or in your default browser.

It also runs in your browser at https://christiansystems.org/box/

Free and open source under the Christian Systems License 1.0 (GPL-3.0-only). See LICENSE.
Source: https://github.com/christiansystems/ChristianBox
