@echo off
rem Opens ChristianSprite in Microsoft Edge as its own window. Settings stay in %LOCALAPPDATA%\Christian Systems\ChristianSprite.
setlocal
set "APP=%~dp0app\index.html"
set "URL=file:///%APP:\=/%"
set "DATA=%LOCALAPPDATA%\Christian Systems\ChristianSprite"
start "" msedge --app="%URL%" --user-data-dir="%DATA%" --no-first-run 2>nul || start "" "%APP%"
