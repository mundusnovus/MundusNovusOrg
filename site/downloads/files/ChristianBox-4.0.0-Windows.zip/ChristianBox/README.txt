ChristianBox 4.0.0
==================

A free music maker built on BeepBox, with a Composer that writes music with you.

To start it, open the folder and double-click ChristianBox.cmd. It opens in Microsoft Edge as its own window.
For a shortcut on your desktop, right-click ChristianBox.cmd and choose Send to > Desktop.

It also runs in your browser at https://christiansystems.org/box/

Free and open source under the Christian Systems License 1.0 (GPL-3.0-only). See LICENSE.
Source: https://github.com/christiansystems/ChristianBox
