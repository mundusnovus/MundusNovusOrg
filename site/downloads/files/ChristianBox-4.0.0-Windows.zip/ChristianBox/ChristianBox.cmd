@echo off
rem Opens ChristianBox in Microsoft Edge as its own window. Settings stay in %LOCALAPPDATA%\Christian Systems\ChristianBox.
setlocal
set "APP=%~dp0app\index.html"
set "URL=file:///%APP:\=/%"
set "DATA=%LOCALAPPDATA%\Christian Systems\ChristianBox"
start "" msedge --app="%URL%" --user-data-dir="%DATA%" --no-first-run 2>nul || start "" "%APP%"
