@echo off
rem Opens MNBox in Microsoft Edge as its own window. Settings stay in %LOCALAPPDATA%\Mundus Novus\MNBox.
setlocal
set "APP=%~dp0app\index.html"
set "URL=file:///%APP:\=/%"
set "DATA=%LOCALAPPDATA%\Mundus Novus\MNBox"
start "" msedge --app="%URL%" --user-data-dir="%DATA%" --no-first-run 2>nul || start "" "%APP%"
