@echo off
rem Opens Asteria Sprite in Microsoft Edge as its own window. Settings stay in %LOCALAPPDATA%\Asteria Technology\Asteria Sprite.
setlocal
set "APP=%~dp0app\index.html"
set "URL=file:///%APP:\=/%"
set "DATA=%LOCALAPPDATA%\Asteria Technology\Asteria Sprite"
start "" msedge --app="%URL%" --user-data-dir="%DATA%" --no-first-run 2>nul || start "" "%APP%"
