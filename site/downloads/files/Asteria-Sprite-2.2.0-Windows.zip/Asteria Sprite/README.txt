Asteria Sprite 2.2.0
====================

A free pixel-art editor and animator with an assistant that draws with you.

To start it, open the folder and double-click Asteria Sprite.cmd. It opens in Microsoft Edge as its own window.
For a shortcut on your desktop, right-click Asteria Sprite.cmd and choose Send to > Desktop.

It also runs in your browser at https://asteria.technology/sprite/

Free and open source under the Asteria License 1.0 (GPL-3.0-only). See LICENSE.
Source: https://github.com/mundusnovus/MNSprite
