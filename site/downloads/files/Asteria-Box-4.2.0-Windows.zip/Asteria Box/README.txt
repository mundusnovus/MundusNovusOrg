Asteria Box 4.2.0
=================

A free music maker built on BeepBox, with a Composer that writes music with you.

To start it, open the folder and double-click Asteria Box.cmd. It opens in Microsoft Edge as its own window.
For a shortcut on your desktop, right-click Asteria Box.cmd and choose Send to > Desktop.

It also runs in your browser at https://asteria.technology/box/

Free and open source under the Asteria License 1.0 (GPL-3.0-only). See LICENSE.
Source: https://github.com/mundusnovus/MNBox
