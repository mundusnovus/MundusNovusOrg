@echo off
rem Opens Asteria Box in Microsoft Edge as its own window. Settings stay in %LOCALAPPDATA%\Asteria Technology\Asteria Box.
setlocal
set "APP=%~dp0app\index.html"
set "URL=file:///%APP:\=/%"
set "DATA=%LOCALAPPDATA%\Asteria Technology\Asteria Box"
start "" msedge --app="%URL%" --user-data-dir="%DATA%" --no-first-run 2>nul || start "" "%APP%"
