Asteria Sprite 2.2.0
====================

A free pixel-art editor and animator with an assistant that draws with you.

To start it, run ./asteria-sprite in this folder. It opens as its own window in Chromium, Chrome, Edge or Brave if one is installed, or in your default browser.

It also runs in your browser at https://asteria.technology/sprite/

Free and open source under the Asteria License 1.0 (GPL-3.0-only). See LICENSE.
Source: https://github.com/mundusnovus/MNSprite
