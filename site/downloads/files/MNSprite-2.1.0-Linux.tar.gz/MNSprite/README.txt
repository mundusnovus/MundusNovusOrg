MNSprite 2.1.0
==============

A free pixel-art editor and animator with an assistant that draws with you.

To start it, run ./mn-sprite in this folder. It opens as its own window in Chromium, Chrome, Edge or Brave if one is installed, or in your default browser.

It also runs in your browser at https://mundusnovus.org/sprite/

Free and open source under the Mundus Novus License 1.0 (GPL-3.0-only). See LICENSE.
Source: https://github.com/mundusnovus/MNSprite
