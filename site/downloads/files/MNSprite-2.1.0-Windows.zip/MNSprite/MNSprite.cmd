@echo off
rem Opens MNSprite in Microsoft Edge as its own window. Settings stay in %LOCALAPPDATA%\Mundus Novus\MNSprite.
setlocal
set "APP=%~dp0app\index.html"
set "URL=file:///%APP:\=/%"
set "DATA=%LOCALAPPDATA%\Mundus Novus\MNSprite"
start "" msedge --app="%URL%" --user-data-dir="%DATA%" --no-first-run 2>nul || start "" "%APP%"
