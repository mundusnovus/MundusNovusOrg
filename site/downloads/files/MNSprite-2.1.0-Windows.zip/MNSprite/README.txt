MNSprite 2.1.0
==============

A free pixel-art editor and animator with an assistant that draws with you.

To start it, open the folder and double-click MNSprite.cmd. It opens in Microsoft Edge as its own window.
For a shortcut on your desktop, right-click MNSprite.cmd and choose Send to > Desktop.

It also runs in your browser at https://mundusnovus.org/sprite/

Free and open source under the Mundus Novus License 1.0 (GPL-3.0-only). See LICENSE.
Source: https://github.com/mundusnovus/MNSprite
